# EA on a Page — Artifact Navigator

An interactive web app for navigating Svyatoslav Kotusev's **Enterprise Architecture on a Page** framework (v2.2).

Browse 17 EA artifacts across 6 families, filter by EA process, compare related artifacts, and understand how they connect — all backed by peer-reviewed research.

## Features

- **Explore** — Browse all artifacts with filters for focus (Business/IT), importance, and lifecycle
- **Find** — Filter by Kotusev's three EA processes: Strategic Planning, Technology Optimisation, Initiative Delivery
- **Detail view** — Full artifact profiles with SVG visual representations, relationships, and practical notes
- **Compare mode** — Side-by-side comparison of commonly confused artifacts
- **Accessibility** — Font size slider, light/dark theme toggle, mobile-responsive

## Research basis

Artifact classifications follow the CSVLOD taxonomy from:

> Kotusev, S., Kurnia, S., & Dilnutt, R. (2022). "The practical roles of enterprise architecture artifacts: A classification and relationship." *Information and Software Technology*, 147, 106897.

The three EA processes (Strategic Planning, Technology Optimisation, Initiative Delivery) are from:

> Kotusev, S. (2019). "Enterprise Architecture Practice on a Page." BCS.

## Deploy to Cloudflare Pages

1. Push this repo to GitHub
2. Go to [Cloudflare Pages](https://pages.cloudflare.com)
3. Connect your GitHub repo
4. Set these build settings:
   - **Build command:** (leave empty)
   - **Build output directory:** `public`
5. Deploy

That's it — no build step, no dependencies. It's a single HTML file.

## Local development

```bash
npx serve public -l 3000
```

## License

MIT

## Credits

- Framework: [Svyatoslav Kotusev](https://eaonapage.com) — EA on a Page (v2.2)
- App: [Luiz Santana](https://www.linkedin.com/in/luizsantana)
